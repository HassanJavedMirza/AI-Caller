"""
routers/settings.py — Scheduler configuration.
There is always exactly ONE row in scheduler_settings (id = 1).
GET returns it; PATCH updates it.
"""

from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database import get_db
from schemas  import SettingsOut, SettingsUpdate
import models
import auth as auth_utils

router = APIRouter(prefix="/settings", tags=["Settings"])

DEFAULT_SETTINGS = {
    "id":                   1,
    "call_time":            "09:00",
    "active_days":          ["Mon", "Tue", "Wed", "Thu", "Fri"],
    "is_active":            True,
    "max_retries":          3,
    "retry_interval_hours": 24,
}


def _get_or_create_settings(db: Session) -> models.SchedulerSettings:
    """Fetch the settings row, creating it with defaults if it doesn't exist yet."""
    settings = db.query(models.SchedulerSettings).filter(
        models.SchedulerSettings.id == 1
    ).first()

    if not settings:
        settings = models.SchedulerSettings(**DEFAULT_SETTINGS)
        db.add(settings)
        db.commit()
        db.refresh(settings)

    return settings


@router.get("/", response_model=SettingsOut)
def get_settings(
    db: Session = Depends(get_db),
    _:  models.Admin = Depends(auth_utils.get_current_admin),
):
    """Return current scheduler settings."""
    return _get_or_create_settings(db)


@router.patch("/", response_model=SettingsOut)
def update_settings(
    payload: SettingsUpdate,
    db:      Session = Depends(get_db),
    _:       models.Admin = Depends(auth_utils.get_current_admin),
):
    """
    Update scheduler settings.
    Send only the fields you want to change.

    Example — change call time to 10:30 AM and limit to 3 days:
    {
        "call_time": "10:30",
        "active_days": ["Mon", "Wed", "Fri"]
    }
    """
    settings = _get_or_create_settings(db)

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(settings, field, value)

    settings.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(settings)
    return settings
