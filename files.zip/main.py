"""
main.py — FastAPI application entry point.

Run with:  uvicorn main:app --reload --port 8000
Docs at:   http://localhost:8000/docs
"""

import os
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, check_connection, engine
from routers  import auth, admins, clients, invoices, calls, settings

load_dotenv()


# ── Startup / Shutdown ────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create tables that don't exist yet (safe for existing tables)
    Base.metadata.create_all(bind=engine)

    if check_connection():
        print("✅ Database connected successfully")
    else:
        print("❌ Database connection FAILED — check your .env settings")

    yield
    print("👋 Server shutting down")


# ── App ───────────────────────────────────────────────────────────────────

app = FastAPI(
    title       = "AI Debt Reminder — Admin API",
    description = (
        "Backend API for managing clients, invoices, AI call logs, "
        "and scheduler settings. All endpoints (except /auth/login) "
        "require a valid JWT bearer token."
    ),
    version  = "1.0.0",
    lifespan = lifespan,
)


# ── CORS (allow the frontend to talk to the API) ──────────────────────────
# For local development this is wide open.
# Lock this down to your real domain before going to production.

app.add_middleware(
    CORSMiddleware,
    allow_origins     = ["*"],
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)


# ── Routers ───────────────────────────────────────────────────────────────

app.include_router(auth.router)
app.include_router(admins.router)
app.include_router(clients.router)
app.include_router(invoices.router)
app.include_router(calls.router)
app.include_router(settings.router)


# ── Health check ──────────────────────────────────────────────────────────

@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "message": "AI Debt Reminder API is running"}


@app.get("/health", tags=["Health"])
def health():
    db_ok = check_connection()
    return {
        "api":      "ok",
        "database": "ok" if db_ok else "error",
    }
