"""
routers/calls.py — Call log management.
Admins can view all call logs, filter them, and listen to recordings.
Manual log creation is here for testing; real creation will be done
by the Vapi webhook when AI calling is integrated.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import get_db
from schemas  import CallCreate, CallOut
import models
import auth as auth_utils

router = APIRouter(prefix="/calls", tags=["Calls"])


# ── List all calls ────────────────────────────────────────────────────────

@router.get("/", response_model=list[CallOut])
def list_calls(
    skip:       int = Query(0,    ge=0),
    limit:      int = Query(100,  ge=1, le=500),
    invoice_id: int = Query(None, description="Filter by invoice"),
    status:     str = Query(None, description="Filter by call_status"),
    db:         Session = Depends(get_db),
    _:          models.Admin = Depends(auth_utils.get_current_admin),
):
    """Return call logs, newest first."""
    q = db.query(models.Call).order_by(models.Call.created_at.desc())
    if invoice_id:
        q = q.filter(models.Call.invoice_id == invoice_id)
    if status:
        q = q.filter(models.Call.call_status == status)
    return q.offset(skip).limit(limit).all()


# ── Get single call ────────────────────────────────────────────────────────

@router.get("/{call_id}", response_model=CallOut)
def get_call(
    call_id: int,
    db:      Session = Depends(get_db),
    _:       models.Admin = Depends(auth_utils.get_current_admin),
):
    call = db.query(models.Call).filter(models.Call.call_id == call_id).first()
    if not call:
        raise HTTPException(status_code=404, detail="Call log not found")
    return call


# ── Get full transcript ────────────────────────────────────────────────────

@router.get("/{call_id}/transcript")
def get_transcript(
    call_id: int,
    db:      Session = Depends(get_db),
    _:       models.Admin = Depends(auth_utils.get_current_admin),
):
    """Return just the transcript and AI summary for a call — used in the review panel."""
    call = db.query(models.Call).filter(models.Call.call_id == call_id).first()
    if not call:
        raise HTTPException(status_code=404, detail="Call log not found")
    return {
        "call_id":        call.call_id,
        "invoice_id":     call.invoice_id,
        "call_status":    call.call_status,
        "duration_seconds": call.duration_seconds,
        "recording_url":  call.recording_url,
        "transcript":     call.transcript,
        "ai_summary":     call.ai_summary,
        "created_at":     call.created_at,
    }


# ── Manual log (for testing before Vapi is wired up) ─────────────────────

@router.post("/", response_model=CallOut, status_code=201)
def create_call_log(
    payload: CallCreate,
    db:      Session = Depends(get_db),
    _:       models.Admin = Depends(auth_utils.get_current_admin),
):
    """
    Manually create a call log entry.
    In production this will be called by the Vapi webhook automatically.
    """
    if not db.query(models.Invoice).filter(models.Invoice.invoice_id == payload.invoice_id).first():
        raise HTTPException(status_code=404, detail="Invoice not found")

    call = models.Call(**payload.model_dump())
    db.add(call)
    db.commit()
    db.refresh(call)
    return call


# ── Delete a log ──────────────────────────────────────────────────────────

@router.delete("/{call_id}", status_code=204)
def delete_call(
    call_id: int,
    db:      Session = Depends(get_db),
    _:       models.Admin = Depends(auth_utils.get_current_admin),
):
    call = db.query(models.Call).filter(models.Call.call_id == call_id).first()
    if not call:
        raise HTTPException(status_code=404, detail="Call log not found")
    db.delete(call)
    db.commit()
